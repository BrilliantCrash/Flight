﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PlaneController : MonoBehaviour {

	public float speedChange;
	public float maxSpeed;
	public float rollSpeed;
	public float yawSpeed;
	public float pitchSpeed;
	public float liftBarrier;
	public GameObject plane;
	//public Rigidbody rb;

	public CanvasGroup cg;
	private bool explode = false;
	private bool finishedFading = true;
	public float fadeSpeed;
	public Vector3 respawnCoords;
	public Quaternion respawnHeading;
	public float respawnThrottle;
	public float throttle;

	// Use this for initialization
	void Start () {
		//rb = plane.GetComponent<Rigidbody>();
		throttle = respawnThrottle;
	}

	// Update is called once per frame
	void FixedUpdate () {
		float rollH = Input.GetAxis("Horizontal") * rollSpeed;
		float rollV = Input.GetAxis("Vertical") * pitchSpeed * (-1);
		if (Input.GetKey (KeyCode.LeftShift) == true) {
			if (throttle + speedChange > .8)
				throttle = .8f;
			else 
				throttle += speedChange;
		} 
		if (Input.GetKey (KeyCode.LeftControl) == true) {
			if (throttle - speedChange < .2) 
				throttle = .2f;
			else
				throttle -= speedChange;
		}

		if (Input.GetKey (KeyCode.LeftShift) == false && Input.GetKey(KeyCode.LeftControl) == false) {
			if (throttle > .5) {
				if (throttle - speedChange < .5) 
					throttle = .5f;
				else 
					throttle -= speedChange;
			} else if (throttle < .5) {
				if (throttle + speedChange > .5)
					throttle = .5f;
				else 
					throttle += speedChange;
			}
		}
		plane.transform.Rotate(new Vector3(rollV,0,rollH) * Time.deltaTime);
		plane.transform.position += transform.forward * Time.deltaTime * -(throttle * maxSpeed);

		explodeCheck();
	}

	void OnTriggerEnter (Collider collision) {
		if (collision.tag == "Obstacle") {
			explode = true;
			finishedFading = false;
			cg.alpha = 1;
		}
	}

	void explodeCheck() {
		if (explode) {
			plane.transform.position = respawnCoords;
			plane.transform.rotation = respawnHeading;
			throttle = respawnThrottle;
			explode = false;
		}
		if (!finishedFading) {
			if (cg.alpha - fadeSpeed < 0 || cg.alpha == 0) {
				cg.alpha = 0;
				finishedFading = true;
			} else 
				cg.alpha -= fadeSpeed;
		} 
	}
}

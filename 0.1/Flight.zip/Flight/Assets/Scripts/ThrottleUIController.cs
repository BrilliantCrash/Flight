﻿using UnityEngine;
using System.Collections;

public class ThrottleUIController : MonoBehaviour {

	GameObject plane;

	// Use this for initialization
	void Start () {
		plane = GameObject.FindGameObjectWithTag("Player");
	}
	
	// Update is called once per frame
	void Update () {
		transform.localScale = new Vector3 (.01f,plane.GetComponent<PlaneController>().throttle,1);
	}
}
